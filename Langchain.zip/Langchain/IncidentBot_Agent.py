from fastapi import FastAPI, File, UploadFile, Form, HTTPException
import pandas as pd
from langchain_groq import ChatGroq
from langchain_core.prompts import ChatPromptTemplate
from langchain_community.vectorstores import Chroma
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_core.output_parsers import StrOutputParser
from langchain_experimental.agents.agent_toolkits import create_csv_agent
import os

os.environ["GROQ_API_KEY"] = grok_key

app = FastAPI()

llm = ChatGroq(model="llama-3.1-8b-instant")
prompt = ChatPromptTemplate.from_messages([
    ("system", "You are an IT incident analyst. Answer questions based on the incident data clearly in simple."),
    ("user", "{question}\n\nIncident Data:\n{data}")
])
chain = prompt | llm | StrOutputParser()

agent = None
embeddings = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")

@app.post("/upload_csv")
async def upload_csv(file: UploadFile = File(...)):
    global agent
    agent = create_csv_agent(llm, file.file, verbose=True, allow_dangerous_code=True)
    return {"message": "CSV uploaded and stored in vector DB successfully."}

@app.post("/chat")
async def chat_with_csv(question: str = Form(...)):
    response = agent.run(question)
    return {"response": response}