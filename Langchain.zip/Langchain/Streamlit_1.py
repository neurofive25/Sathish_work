import streamlit as st
import requests
import pandas as pd
from io import StringIO

# FastAPI backend URL
FASTAPI_URL = "http://localhost:8000"  # Update this if your FastAPI runs on different URL

# Page configuration
st.set_page_config(
    page_title="IT Incident Analyst Chatbot",
    page_icon="🔍",
    layout="wide"
)

# Custom CSS for better styling
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        color: #1f77b4;
        text-align: center;
        margin-bottom: 2rem;
    }
    .chat-container {
        background-color: #f0f2f6;
        border-radius: 10px;
        padding: 20px;
        margin: 10px 0;
    }
    .user-message {
        background-color: #d4edda;
        padding: 10px;
        border-radius: 10px;
        margin: 5px 0;
        border-left: 5px solid #28a745;
    }
    .bot-message {
        background-color: #ffffff;
        padding: 10px;
        border-radius: 10px;
        margin: 5px 0;
        border-left: 5px solid #007bff;
    }
    .upload-section {
        background-color: #e7f3ff;
        padding: 20px;
        border-radius: 10px;
        margin-bottom: 20px;
    }
</style>
""", unsafe_allow_html=True)

# Initialize session state
if "messages" not in st.session_state:
    st.session_state.messages = []
if "csv_uploaded" not in st.session_state:
    st.session_state.csv_uploaded = False
if "uploaded_file_name" not in st.session_state:
    st.session_state.uploaded_file_name = None

def upload_csv_to_backend(file):
    """Upload CSV file to FastAPI backend"""
    try:
        files = {"file": (file.name, file.getvalue(), "text/csv")}
        response = requests.post(f"{FASTAPI_URL}/upload_csv", files=files)
        if response.status_code == 200:
            return True, "CSV uploaded successfully!"
        else:
            return False, f"Error uploading CSV: {response.text}"
    except Exception as e:
        return False, f"Connection error: {str(e)}"

def send_chat_question(question):
    """Send question to FastAPI backend"""
    try:
        data = {"question": question}
        response = requests.post(f"{FASTAPI_URL}/chat", data=data)
        if response.status_code == 200:
            return True, response.json()["response"]
        else:
            return False, f"Error: {response.text}"
    except Exception as e:
        return False, f"Connection error: {str(e)}"

# Main application
def main():
    st.markdown('<h1 class="main-header">🔍 IT Incident Analyst Chatbot</h1>', unsafe_allow_html=True)
    
    # Sidebar for file upload
    with st.sidebar:
        st.header("📁 Upload CSV File")
        st.markdown('<div class="upload-section">', unsafe_allow_html=True)
        
        uploaded_file = st.file_uploader(
            "Choose a CSV file", 
            type="csv",
            help="Upload your IT incident data CSV file"
        )
        
        if uploaded_file is not None:
            # Display file info
            st.success(f"File selected: {uploaded_file.name}")
            
            # Show preview of the CSV
            try:
                df = pd.read_csv(uploaded_file)
                st.subheader("📊 Data Preview")
                st.dataframe(df.head(), use_container_width=True)
                st.write(f"Shape: {df.shape[0]} rows, {df.shape[1]} columns")
            except Exception as e:
                st.error(f"Error reading CSV: {str(e)}")
            
            # Upload button
            if st.button("🚀 Upload to Analysis System", use_container_width=True):
                with st.spinner("Uploading CSV to analysis system..."):
                    success, message = upload_csv_to_backend(uploaded_file)
                    if success:
                        st.session_state.csv_uploaded = True
                        st.session_state.uploaded_file_name = uploaded_file.name
                        st.session_state.messages = []  # Clear previous chat
                        st.success(message)
                    else:
                        st.error(message)
        
        st.markdown('</div>', unsafe_allow_html=True)
        
        # Display current status
        st.subheader("📈 System Status")
        if st.session_state.csv_uploaded:
            st.success("✅ CSV Loaded")
            st.info(f"File: {st.session_state.uploaded_file_name}")
        else:
            st.warning("⏳ No CSV loaded")
        
        # Quick actions
        st.subheader("⚡ Quick Actions")
        if st.button("Clear Chat", use_container_width=True):
            st.session_state.messages = []
            st.rerun()
        
        # Information section
        st.subheader("ℹ️ About")
        st.info("""
        This chatbot helps analyze IT incident data. 
        Upload a CSV file and ask questions about:
        - Incident trends
        - Resolution times
        - Category analysis
        - Root causes
        """)

    # Main chat area
    col1, col2 = st.columns([2, 1])
    
    with col1:
        st.subheader("💬 Chat with Your Data")
        
        # Display chat messages
        chat_container = st.container()
        with chat_container:
            for message in st.session_state.messages:
                if message["role"] == "user":
                    st.markdown(f'<div class="user-message"><strong>You:</strong> {message["content"]}</div>', unsafe_allow_html=True)
                else:
                    st.markdown(f'<div class="bot-message"><strong>Analyst:</strong> {message["content"]}</div>', unsafe_allow_html=True)
        
        # Chat input
        if st.session_state.csv_uploaded:
            question = st.chat_input("Ask a question about your incident data...")
            
            if question:
                # Add user message to chat
                st.session_state.messages.append({"role": "user", "content": question})
                
                # Get bot response
                with st.spinner("Analyzing your data..."):
                    success, response = send_chat_question(question)
                
                if success:
                    st.session_state.messages.append({"role": "assistant", "content": response})
                else:
                    st.session_state.messages.append({"role": "assistant", "content": f"❌ {response}"})
                
                st.rerun()
        else:
            st.info("📁 Please upload a CSV file to start chatting with your data")
    
    with col2:
        st.subheader("💡 Sample Questions")
        if st.session_state.csv_uploaded:
            sample_questions = [
                "What are the most common incident types?",
                "Show me the resolution time trends",
                "Which teams handle the most incidents?",
                "What's the average resolution time?",
                "List incidents that took longest to resolve",
                "Show incident distribution by priority"
            ]
            
            for i, q in enumerate(sample_questions):
                if st.button(f"{i+1}. {q}", use_container_width=True, key=f"sample_{i}"):
                    # Add sample question to chat
                    st.session_state.messages.append({"role": "user", "content": q})
                    
                    # Get bot response
                    with st.spinner("Analyzing your data..."):
                        success, response = send_chat_question(q)
                    
                    if success:
                        st.session_state.messages.append({"role": "assistant", "content": response})
                    else:
                        st.session_state.messages.append({"role": "assistant", "content": f"❌ {response}"})
                    
                    st.rerun()
        else:
            st.info("Upload a CSV to see sample questions")

# Footer
st.markdown("---")
st.markdown(
    "**IT Incident Analyst Chatbot** | Built with FastAPI & Streamlit | "
    "Upload your incident data CSV and start analyzing!"
)

if __name__ == "__main__":
    main()