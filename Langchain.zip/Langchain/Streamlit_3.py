import streamlit as st
import requests
import pandas as pd
import io
import time

# Configuration
FASTAPI_BASE_URL = "http://localhost:8000"  # Update this if your FastAPI runs on different URL

def main():
    st.set_page_config(
        page_title="IT Incident Analyst",
        page_icon="🔍",
        layout="wide"
    )
    
    st.title("🔍 IT Incident Analyst")
    st.markdown("Upload your incident CSV file and ask questions about your data")
    
    # Initialize session state
    if 'csv_uploaded' not in st.session_state:
        st.session_state.csv_uploaded = False
    if 'chat_history' not in st.session_state:
        st.session_state.chat_history = []
    
    # Sidebar for file upload
    with st.sidebar:
        st.header("📁 Upload CSV")
        uploaded_file = st.file_uploader(
            "Choose a CSV file", 
            type=['csv'],
            help="Upload your IT incident data in CSV format"
        )
        
        if uploaded_file is not None:
            try:
                # Display file info
                file_details = {
                    "Filename": uploaded_file.name,
                    "File size": f"{uploaded_file.size / 1024:.2f} KB"
                }
                st.write("File details:")
                st.json(file_details)
                
                # Preview the data
                st.subheader("Data Preview")
                df = pd.read_csv(uploaded_file)
                st.dataframe(df.head(), use_container_width=True)
                
                # Upload to FastAPI backend
                if st.button("📤 Process CSV", type="primary"):
                    with st.spinner("Uploading and processing CSV..."):
                        try:
                            files = {"file": (uploaded_file.name, uploaded_file.getvalue(), "text/csv")}
                            response = requests.post(f"{FASTAPI_BASE_URL}/upload_csv", files=files)
                            
                            if response.status_code == 200:
                                st.session_state.csv_uploaded = True
                                st.success("✅ CSV uploaded and processed successfully!")
                                st.session_state.chat_history = []  # Clear previous chat
                            else:
                                st.error(f"❌ Error uploading CSV: {response.text}")
                                
                        except requests.exceptions.ConnectionError:
                            st.error("🚫 Cannot connect to FastAPI backend. Make sure the server is running.")
                        except Exception as e:
                            st.error(f"❌ Error: {str(e)}")
                            
            except Exception as e:
                st.error(f"❌ Error reading CSV file: {str(e)}")
        
        # Clear chat history
        if st.button("🗑️ Clear Chat History"):
            st.session_state.chat_history = []
            st.rerun()
    
    # Main chat interface
    col1, col2 = st.columns([2, 1])
    
    with col1:
        st.header("💬 Chat with Your Data")
        
        if not st.session_state.csv_uploaded:
            st.info("👆 Please upload and process a CSV file in the sidebar to start chatting")
        else:
            # Display chat history
            chat_container = st.container()
            with chat_container:
                for message in st.session_state.chat_history:
                    with st.chat_message(message["role"]):
                        st.markdown(message["content"])
            
            # Chat input
            if prompt := st.chat_input("Ask a question about your incident data..."):
                # Add user message to chat history
                st.session_state.chat_history.append({"role": "user", "content": prompt})
                
                # Display user message
                with st.chat_message("user"):
                    st.markdown(prompt)
                
                # Get AI response
                with st.chat_message("assistant"):
                    with st.spinner("Analyzing data..."):
                        try:
                            response = requests.post(
                                f"{FASTAPI_BASE_URL}/chat",
                                data={"question": prompt}
                            )
                            
                            if response.status_code == 200:
                                ai_response = response.json()["response"]
                                st.markdown(ai_response)
                                st.session_state.chat_history.append({"role": "assistant", "content": ai_response})
                            else:
                                error_msg = f"❌ Error: {response.text}"
                                st.markdown(error_msg)
                                st.session_state.chat_history.append({"role": "assistant", "content": error_msg})
                                
                        except requests.exceptions.ConnectionError:
                            error_msg = "🚫 Cannot connect to the analysis service. Please make sure the backend is running."
                            st.markdown(error_msg)
                            st.session_state.chat_history.append({"role": "assistant", "content": error_msg})
                        except Exception as e:
                            error_msg = f"❌ Unexpected error: {str(e)}"
                            st.markdown(error_msg)
                            st.session_state.chat_history.append({"role": "assistant", "content": error_msg})
    
    with col2:
        st.header("📊 Quick Actions")
        
        if st.session_state.csv_uploaded:
            st.markdown("### Sample Questions")
            
            sample_questions = [
                "What are the most common incident types?",
                "Show me the resolution times for high priority incidents",
                "Which teams handle the most incidents?",
                "What's the average resolution time?",
                "List all open incidents",
                "Show incidents by priority level"
            ]
            
            for question in sample_questions:
                if st.button(question, key=question):
                    # This will trigger the chat input with the sample question
                    st.session_state.sample_question = question
                    st.rerun()
            
            # Handle sample question selection
            if 'sample_question' in st.session_state:
                # Use JavaScript to set the chat input (workaround)
                st.markdown(f"""
                <script>
                    const input = document.querySelector('[data-testid="stChatInput"] textarea');
                    if (input) {{
                        input.value = '{st.session_state.sample_question}';
                        input.dispatchEvent(new Event('input', {{ bubbles: true }}));
                    }}
                </script>
                """, unsafe_allow_html=True)
                del st.session_state.sample_question

if __name__ == "__main__":
    main()