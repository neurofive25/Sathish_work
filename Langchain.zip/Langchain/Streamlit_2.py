import streamlit as st
import requests

st.set_page_config(page_title="IT Incident Chatbot", layout="centered")
st.title("🧠 IT Incident Chatbot")

# Backend URL
API_URL = "http://localhost:8000"

# Upload CSV
st.header("📁 Upload Incident CSV")
uploaded_file = st.file_uploader("Choose a CSV file", type="csv")

if uploaded_file:
    files = {"file": uploaded_file.getvalue()}
    response = requests.post(f"{API_URL}/upload_csv", files={"file": uploaded_file})
    if response.status_code == 200:
        st.success("CSV uploaded successfully and stored in vector DB.")
    else:
        st.error(f"Upload failed: {response.json()['detail']}")

# Ask a question
st.header("💬 Ask a Question")
question = st.text_input("Type your question about the incidents")

if question:
    response = requests.post(f"{API_URL}/chat", data={"question": question})
    if response.status_code == 200:
        st.markdown("### 🤖 Chatbot Response")
        st.write(response.json()["response"])
    else:
        st.error(f"Error: {response.json()['detail']}")