# 🧠 IT Incident Chatbot API Documentation

This backend chatbot allows users to:
- Upload a CSV file of IT incidents
- Store incident data in a vector database
- Ask questions about the incidents
- Get intelligent responses powered by Groq LLM via LangChain

---

## 📦 1. Packages Used and Their Purpose

| Package | Purpose |
|--------|---------|
| `fastapi` | Web framework for building REST APIs |
| `uvicorn` | ASGI server to run FastAPI apps |
| `pandas` | Reads and processes CSV files |
| `langchain` | Framework for building LLM-powered applications |
| `langchain-groq` | Connects LangChain to Groq-hosted LLMs |
| `langchain-community` | Access to community-supported integrations like Chroma and Hugging Face |
| `chromadb` | Vector database for storing and retrieving text based on semantic similarity |
| `sentence-transformers` | Embedding model to convert text into vector form |
| `python-multipart` | Enables file uploads in FastAPI endpoints |

---

## ⚙️ 2. Functionality of the Code

### 🔁 `/upload_csv` Endpoint
- Accepts a CSV file via `form-data`
- Converts each row into a string
- Embeds the rows using Hugging Face model
- Stores them in a Chroma vector database

### 💬 `/chat` Endpoint
- Accepts a user question via `form-data`
- Retrieves top 5 semantically similar rows from the vector DB
- Sends the question + relevant data to Groq LLM via LangChain
- Returns the LLM-generated answer

---

## 📄 3. Requirements File (`requirements.txt`)

```txt
fastapi
uvicorn
pandas
langchain
langchain-groq
langchain-community
chromadb
sentence-transformers
python-multipart



pip install -r requirements.txt